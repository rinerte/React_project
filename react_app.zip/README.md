# React + Vite + Router + redux + mock for API (msw)

