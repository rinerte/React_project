// src/pages/About.jsx
import React from 'react'

const About = () => (
  <div className="p-4">
    <h1 className="text-2xl font-bold">About Page</h1>
  </div>
)

export default About
